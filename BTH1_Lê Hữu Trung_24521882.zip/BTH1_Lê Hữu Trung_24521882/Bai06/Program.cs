﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Bai6
{
    internal class Program
    {
        // Hàm tạo ma trận ngẫu nhiên có kích thước n x m trong khoảng [min, max]
        static int[,] TaoMaTranNgauNhien(int n, int m, int min, int max)
        {
            Random rnd = new Random();
            int[,] a = new int[n, m];
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                    a[i, j] = rnd.Next(min, max + 1);
            return a;
        }

        // Hàm xuất ma trận ra màn hình
        static void XuatMaTran(int[,] a)
        {
            int n = a.GetLength(0);
            int m = a.GetLength(1);
            Console.WriteLine("\nMa tran:");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                    Console.Write($"{a[i, j],5}");
                Console.WriteLine();
            }
        }

        // Hàm tìm phần tử lớn nhất và nhỏ nhất trong ma trận
        static void TimMaxMin(int[,] a)
        {
            int max = a[0, 0], min = a[0, 0];
            foreach (int x in a)
            {
                if (x > max) max = x;
                if (x < min) min = x;
            }
            Console.WriteLine($"Phan tu lon nhat: {max}");
            Console.WriteLine($"Phan tu nho nhat: {min}");
        }

        // Hàm tìm dòng có tổng các phần tử lớn nhất trong ma trận
        static void TimDongCoTongLonNhat(int[,] a)
        {
            int n = a.GetLength(0);
            int m = a.GetLength(1);
            int maxSum = int.MinValue, dongMax = 0;

            for (int i = 0; i < n; i++)
            {
                int sum = 0;
                for (int j = 0; j < m; j++)
                    sum += a[i, j];
                if (sum > maxSum)
                {
                    maxSum = sum;
                    dongMax = i;
                }
            }
            Console.WriteLine($"Dong co tong lon nhat la dong {dongMax} (tong = {maxSum})");
        }

        // Hàm kiểm tra một số có phải là số nguyên tố hay không
        static bool LaSoNguyenTo(int n)
        {
            if (n < 2) return false;
            for (int i = 2; i <= Math.Sqrt(n); i++)
                if (n % i == 0) return false;
            return true;
        }

        // Hàm tính tổng tất cả các phần tử không phải là số nguyên tố trong ma trận
        static int TongKhongNguyenTo(int[,] a)
        {
            int sum = 0;
            foreach (int x in a)
                if (!LaSoNguyenTo(x)) sum += x;
            return sum;
        }

        // Hàm xóa dòng thứ k khỏi ma trận (nếu hợp lệ)
        static int[,] XoaDong(int[,] a, int k)
        {
            int n = a.GetLength(0);
            int m = a.GetLength(1);
            if (k < 0 || k >= n)
            {
                Console.WriteLine("Chi so dong khong hop le!");
                return a;
            }

            int[,] b = new int[n - 1, m];
            int newRow = 0;
            for (int i = 0; i < n; i++)
            {
                if (i == k) continue;
                for (int j = 0; j < m; j++)
                    b[newRow, j] = a[i, j];
                newRow++;
            }
            Console.WriteLine($"Da xoa dong {k}.");
            return b;
        }

        // Hàm xóa cột chứa phần tử lớn nhất trong ma trận
        static int[,] XoaCotChuaMax(int[,] a)
        {
            int n = a.GetLength(0);
            int m = a.GetLength(1);
            int max = a[0, 0], cotMax = 0;

            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                    if (a[i, j] > max)
                    {
                        max = a[i, j];
                        cotMax = j;
                    }

            int[,] b = new int[n, m - 1];
            for (int i = 0; i < n; i++)
            {
                int newCol = 0;
                for (int j = 0; j < m; j++)
                {
                    if (j == cotMax) continue;
                    b[i, newCol++] = a[i, j];
                }
            }

            Console.WriteLine($"Da xoa cot {cotMax} chua phan tu lon nhat ({max}).");
            return b;
        }

        // Hàm main: nơi gọi và thực hiện tất cả chức năng
        static void Main(string[] args)
        {
            Console.Write("Nhap so dong n: ");
            int n = int.Parse(Console.ReadLine());
            Console.Write("Nhap so cot m: ");
            int m = int.Parse(Console.ReadLine());
            Console.Write("Nhap dong k muon xoa: ");
            int k = int.Parse(Console.ReadLine());

            int[,] a = TaoMaTranNgauNhien(n, m, -50, 50);

            Console.WriteLine("\n===== KET QUA CAC CHUC NANG =====");
            XuatMaTran(a);
            TimMaxMin(a);
            TimDongCoTongLonNhat(a);
            Console.WriteLine("Tong cac so khong phai la so nguyen to: " + TongKhongNguyenTo(a));
            a = XoaDong(a, k);
            XuatMaTran(a);
            a = XoaCotChuaMax(a);
            XuatMaTran(a);
        }
    }
}

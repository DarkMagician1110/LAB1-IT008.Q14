﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Bai3
{
    internal class Program
    {
        public static bool kiemTra(int ngay, int thang, int nam)
        {
            if (ngay < 0 || thang < 0 || thang > 12 || nam < 0) return false;
            if (nam % 400 == 0 || (nam % 4 == 0 && nam % 100 != 0))
            {
                switch (thang)
                {
                    case 1:
                    case 3:
                    case 5:
                    case 7:
                    case 8:
                    case 10:
                    case 12:
                        if (ngay > 31) return false;
                        break;
                    case 4:
                    case 6:
                    case 9:
                    case 11:
                        if (ngay > 30) return false;
                        break;
                    case 2:
                        if (ngay > 29) return false;
                        break;
                }
            }
            else
            {
                switch (thang)
                {
                    case 1:
                    case 3:
                    case 5:
                    case 7:
                    case 8:
                    case 10:
                    case 12:
                        if (ngay > 31) return false;
                        break;
                    case 4:
                    case 6:
                    case 9:
                    case 11:
                        if (ngay > 30) return false;
                        break;
                    case 2:
                        if (ngay > 28) return false;
                        break;
                }
            }
            return true;
        }
        static void Main(string[] args)
        {
            Console.Write("NhapNgay: ");
            int ngay = int.Parse(Console.ReadLine());
            Console.Write("NhapThang: ");
            int thang = int.Parse(Console.ReadLine());
            Console.Write("NhapNam: ");
            int nam = int.Parse(Console.ReadLine());
            Console.WriteLine(kiemTra(ngay, thang, nam));
        }
    }
}

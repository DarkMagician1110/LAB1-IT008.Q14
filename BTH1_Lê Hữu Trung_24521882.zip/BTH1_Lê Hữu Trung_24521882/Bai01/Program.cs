﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Bai1
{
    internal class Program
    {
        // Tính tổng các số lẻ trong mảng
        public static int TongSoLe(int[] arr)
        {
            int sum = 0;
            for (int i = 0; i < arr.Length; i++)
                if (arr[i] % 2 != 0) sum += arr[i];
            return sum;
        }

        // Kiểm tra số nguyên tố
        public static bool laSoNguyenTo(int n)
        {
            if (n < 2) return false;
            for (int i = 2; i <= Math.Sqrt(n); i++)
                if (n % i == 0) return false;
            return true;
        }

        // Đếm số nguyên tố trong mảng
        public static int DemNguyenTo(int[] arr)
        {
            int cnt = 0;
            for (int i = 0; i < arr.Length; i++)
                if (laSoNguyenTo(arr[i])) cnt++;
            return cnt;
        }

        // Kiểm tra số chính phương
        public static bool laSoChinhPhuong(int n)
        {
            if (n < 0) return false;
            int k = (int)Math.Sqrt(n);
            return k * k == n;
        }

        // Tìm số chính phương nhỏ nhất
        public static int chinhPhuongNN(int[] arr)
        {
            int min = int.MaxValue;
            for (int i = 0; i < arr.Length; i++)
                if (laSoChinhPhuong(arr[i]) && arr[i] < min) min = arr[i];
            return (min == int.MaxValue ? -1 : min);
        }

        static void Main(string[] args)
        {
            Console.Write("Nhap so phan tu n: ");
            int n = int.Parse(Console.ReadLine());
            int[] arr = new int[n];
            Random rd = new Random();

            for (int i = 0; i < n; i++)
                arr[i] = rd.Next(1, 101);

            Console.WriteLine("Mang vua random:");
            foreach (int x in arr) Console.Write(x + " ");
            Console.WriteLine();

            Console.WriteLine("Tong so le: " + TongSoLe(arr));
            Console.WriteLine("So luong so nguyen to: " + DemNguyenTo(arr));
            Console.WriteLine("So chinh phuong nho nhat: " + chinhPhuongNN(arr));
        }
    }
}

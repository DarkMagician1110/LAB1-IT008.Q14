﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace BaiTap
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap ngay: ");
            int ngay = int.Parse(Console.ReadLine());

            Console.Write("Nhap thang: ");
            int thang = int.Parse(Console.ReadLine());

            Console.Write("Nhap nam: ");
            int nam = int.Parse(Console.ReadLine());

            try
            {
                DateTime dt = new DateTime(nam, thang, ngay);
                DayOfWeek thu = dt.DayOfWeek;

                string tenThu = "";

                switch (thu)
                {
                    case DayOfWeek.Sunday: tenThu = "Chu nhat"; break;
                    case DayOfWeek.Monday: tenThu = "Thu hai"; break;
                    case DayOfWeek.Tuesday: tenThu = "Thu ba"; break;
                    case DayOfWeek.Wednesday: tenThu = "Thu tu"; break;
                    case DayOfWeek.Thursday: tenThu = "Thu nam"; break;
                    case DayOfWeek.Friday: tenThu = "Thu sau"; break;
                    case DayOfWeek.Saturday: tenThu = "Thu bay"; break;
                }

                Console.WriteLine($"Ngay {ngay}/{thang}/{nam} la {tenThu}.");
            }
            catch (Exception e)
            {
                Console.WriteLine("Ngay thang nam khong hop le!");
            }
        }
    }
}

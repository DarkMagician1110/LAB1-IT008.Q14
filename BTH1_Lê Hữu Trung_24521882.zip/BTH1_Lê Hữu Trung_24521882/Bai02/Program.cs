﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Bai2
{
    internal class Program
    {
        // Hàm kiểm tra số nguyên tố
        public static bool LaSoNguyenTo(int n)
        {
            if (n < 2) return false;
            for (int i = 2; i <= Math.Sqrt(n); i++)
            {
                if (n % i == 0)
                    return false;
            }
            return true;
        }

        // Hàm tính tổng các số nguyên tố nhỏ hơn n
        public static int TongSoNguyenTo(int n)
        {
            int sum = 0;
            for (int i = 2; i < n; i++) 
            {
                if (LaSoNguyenTo(i))
                    sum += i;
            }
            return sum;
        }

        static void Main(string[] args)
        {
            Console.Write("Nhap so n: ");
            int n = int.Parse(Console.ReadLine()); 

            if (n > 2)
                Console.WriteLine($"Tong cac so nguyen to nho hon {n} la: {TongSoNguyenTo(n)}");
            else
                Console.WriteLine($"Khong co so nguyen to nao nho hon {n}");
        }
    }
}

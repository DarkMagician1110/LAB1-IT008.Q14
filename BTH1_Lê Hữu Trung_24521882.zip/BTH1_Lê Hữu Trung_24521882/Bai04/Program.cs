﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Bai4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Nhap thang: ");
            int thang = int.Parse(Console.ReadLine());

            Console.Write("Nhap nam: ");
            int nam = int.Parse(Console.ReadLine());

            if (thang < 1 || thang > 12 || nam <= 0)
            {
                Console.WriteLine("Du lieu khong hop le!");
            }
            else
            {
                int soNgay = DateTime.DaysInMonth(nam, thang);
                Console.WriteLine($"Thang {thang} nam {nam} co {soNgay} ngay.");
            }
        }
    }
}
